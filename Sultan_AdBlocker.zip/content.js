﻿(function() {
    'use strict';
    
    const host = window.location.hostname;
    let cssAman = '';

    // =======================================================================
    // 1. ZONA YOUTUBE KHUSUS
    // =======================================================================
    if (host.includes('youtube.com')) {
        cssAman = `
            ytd-ad-slot-renderer, ytd-promoted-sparkles-web-renderer,
            .ytd-in-feed-ad-layout-renderer, #masthead-ad, ytd-banner-promo-renderer {
                display: none !important; height: 0px !important;
            }
        `;
        function sikatYouTube() {
            try {
                var skipBtns = document.querySelectorAll('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .videoAdUiSkipButton, [id^="skip-button"], button[class*="ad-skip"]');
                skipBtns.forEach(btn => btn.click());
                var player = document.querySelector('.html5-video-player');
                if (player && player.classList.contains('ad-showing')) {
                    var video = player.querySelector('video');
                    if (video && !isNaN(video.duration)) {
                        video.muted = true; video.currentTime = video.duration || 9999; 
                    }
                }
                var confirmBtn = document.querySelector('yt-confirm-dialog-renderer .yt-spec-button-shape-next');
                if (confirmBtn) confirmBtn.click();
            } catch(e) {}
        }
        setInterval(sikatYouTube, 300);
    }

    // =======================================================================
    // 2. ZONA FACEBOOK KHUSUS
    // =======================================================================
    else if (host.includes('facebook.com')) {
        function sikatFacebook() {
            try {
                var fbElements = document.querySelectorAll('a, span, div, svg');
                fbElements.forEach(function(el) {
                    var label = el.getAttribute('aria-label');
                    var text = el.textContent || '';
                    if ((label && (label.toLowerCase() === 'sponsored' || label.toLowerCase() === 'bersponsor')) || 
                        ((text === 'Sponsored' || text === 'Bersponsor') && el.children.length === 0)) {
                        hancurkanContainerFB(el);
                    }
                });
                var adLinks = document.querySelectorAll('a[href*="utm_medium=ppc"], a[href*="utm_source=meta"], a[href*="utm_id="]');
                adLinks.forEach(function(link) { hancurkanContainerFB(link); });
            } catch(e) {}
        }
        function hancurkanContainerFB(element) {
            var parent = element;
            for (var i = 0; i < 15; i++) {
                if (parent && parent.parentElement) {
                    parent = parent.parentElement;
                    if (parent.tagName === 'DIV' && (parent.getAttribute('data-pagelet') || parent.className.length > 5)) {
                        parent.style.setProperty('display', 'none', 'important');
                        parent.style.setProperty('height', '0px', 'important');
                    }
                }
            }
        }
        setInterval(sikatFacebook, 800);
    }

    // =======================================================================
    // 3. ZONA WEB UMUM & STREAMING (V14.0 - POPUP ANNIHILATOR)
    // =======================================================================
    else {
        // --- A. CSS PEMBUNUH BANNER ---
        cssAman = `
            [href*="zeus"], [src*="zeus"], [href*="88sport"], [src*="88sport"],
            [href*="klik"], [src*="klik"], [href*="poseidon"], [src*="poseidon"],
            [href*="cuan"], [src*="cuan"], [href*="gacor"], [src*="gacor"],
            [href*="ibo"], [src*="ibo"], [href*="idks"], [src*="idks"],
            [href*="slot"], [src*="slot"], [href*="maxwin"], [src*="maxwin"],
            [href*="dewasport"], [src*="dewasport"], [href*="iboslot"], [src*="iboslot"],
            [href*="saiikou"], [src*="saiikou"], [href*="ariadne"], [src*="ariadne"],
            [href*="indokasino"], [src*="indokasino"],
            
            .idmuvi-topbanner, .idmuvi-topbanner-aftermenu, .idmuvi-banner-beforecontent,
            #idmuvi-popup, .gmr-bannerpopup, .floating-banner {
                display: none !important; opacity: 0 !important; height: 0px !important; pointer-events: none !important; width: 0px !important;
            }
            
            div[style*="z-index: 2147"], div[style*="z-index: 9999"], 
            div[style*="position: fixed"][style*="width: 100%"] {
                display: none !important; pointer-events: none !important;
            }
        `;
        
        // --- B. MUTATION OBSERVER (INSTANT IFRAME SANDBOXING) ---
        // Penjara Iframe secara instan detik itu juga sebelum dia sempat melahirkan pop-up
        function penjaraIframe(iframe) {
            if (iframe && iframe.tagName === 'IFRAME') {
                if (!iframe.hasAttribute('sandbox') || iframe.getAttribute('sandbox').includes('allow-popups')) {
                    // Beri izin video jalan, tapi HARAMKAN window pop-up!
                    iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-presentation');
                    console.log('Sultan_AdBlocker: Iframe video dipenjara seketika!');
                }
            }
        }
        
        // Eksekusi untuk iframe yang sudah ada di halaman
        document.querySelectorAll('iframe').forEach(penjaraIframe);

        // Pantau terus! Jika website mencoba membuat iframe baru diam-diam, langsung tangkap!
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Pastikan ini elemen HTML
                        if (node.tagName === 'IFRAME') penjaraIframe(node);
                        // Cek jika iframe diselipkan di dalam div baru
                        const iframes = node.querySelectorAll ? node.querySelectorAll('iframe') : [];
                        iframes.forEach(penjaraIframe);
                    }
                });
            });
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        // --- C. EVENT LISTENER ANTI KLIK JUDI (REVISI BLIND SPOT) ---
        ['click', 'mousedown', 'pointerdown', 'touchstart'].forEach(evt => {
            window.addEventListener(evt, function(e) {
                // Sikat elemen transparan / tombol palsu
                if (e.target.tagName === 'DIV' || e.target.tagName === 'A' || e.target.tagName === 'IMG' || e.target.tagName === 'SVG' || e.target.tagName === 'SPAN') {
                    const rect = e.target.getBoundingClientRect();
                    const style = window.getComputedStyle(e.target);
                    
                    // Jika posisinya melayang (absolute/fixed) dan z-index tinggi
                    if ((style.position === 'absolute' || style.position === 'fixed') && 
                        (style.opacity === '0' || parseInt(style.zIndex) > 10)) {
                        
                        // Abaikan area tombol kontrol video asli biar tetap bisa di-pause/play
                        if (!e.target.closest('.vjs-control-bar') && !e.target.closest('.plyr__controls')) {
                            // Jika ukurannya lumayan besar untuk sebuah jebakan
                            if (rect.width > 50 && rect.height > 50) {
                                e.preventDefault();
                                e.stopImmediatePropagation();
                                e.target.remove();
                                console.log("Sultan_AdBlocker: Lapisan ghaib dihancurkan saat diklik!");
                                return;
                            }
                        }
                    }
                }

                // Cek target link
                var el = e.target.closest('a');
                if (el) {
                    var txt = (el.href || '').toLowerCase();
                    var badWords = ['zeus', '88sport', 'cuan', 'gacor', 'slot', 'ibo', 'idks', 'maxwin', 'dewasport', 'iboslot', 'saiikou', 'ariadne', 'indokasino'];
                    
                    if (badWords.some(word => txt.includes(word))) {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        return;
                    }
                    if (el.target === '_blank' && !txt.includes('gofile.io') && !txt.includes('dm21')) {
                        el.removeAttribute('target'); 
                    }
                }
            }, true);
        });

        // --- D. PENYAPU OTOMATIS (MEMBERSIHKAN SECURITY ALERT) ---
        setInterval(function() {
            try {
                document.querySelectorAll('div, span, p, h1, h2, h3').forEach(el => {
                    if (el.innerText && (el.innerText.includes('Security alert') || el.innerText.includes('Due to security concerns'))) {
                        let parentBox = el.closest('div[style*="fixed"], div[style*="absolute"], div[style*="z-index"]') || el.parentElement;
                        if (parentBox) parentBox.remove();
                        else el.remove();
                    }
                });
            } catch(e) {}
        }, 500);
    }

    if (cssAman !== '') {
        const styleTag = document.createElement('style');
        styleTag.type = 'text/css';
        styleTag.appendChild(document.createTextNode(cssAman));
        if (document.head) document.head.appendChild(styleTag);
        else document.addEventListener("DOMContentLoaded", () => document.head.appendChild(styleTag));
    }
})();
