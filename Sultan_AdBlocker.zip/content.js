﻿(function() {
    'use strict';
    
    const host = window.location.hostname;
    let cssAman = '';

    // =======================================================================
    // 1. ZONA YOUTUBE KHUSUS
    // =======================================================================
    if (host.includes('youtube.com')) {
        cssAman = `
            ytd-ad-slot-renderer, ytd-promoted-sparkles-web-renderer,
            .ytd-in-feed-ad-layout-renderer, #masthead-ad, ytd-banner-promo-renderer {
                display: none !important; height: 0px !important;
            }
        `;
        function sikatYouTube() {
            try {
                var skipBtns = document.querySelectorAll('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .videoAdUiSkipButton, [id^="skip-button"], button[class*="ad-skip"]');
                skipBtns.forEach(btn => btn.click());
                var player = document.querySelector('.html5-video-player');
                if (player && player.classList.contains('ad-showing')) {
                    var video = player.querySelector('video');
                    if (video && !isNaN(video.duration)) {
                        video.muted = true; 
                        video.currentTime = video.duration || 9999; 
                    }
                }
                var confirmBtn = document.querySelector('yt-confirm-dialog-renderer .yt-spec-button-shape-next');
                if (confirmBtn) confirmBtn.click();
            } catch(e) {}
        }
        setInterval(sikatYouTube, 100);
    }

    // =======================================================================
    // 2. ZONA FACEBOOK KHUSUS
    // =======================================================================
    else if (host.includes('facebook.com')) {
        function sikatFacebook() {
            try {
                var fbElements = document.querySelectorAll('a, span, div, svg');
                fbElements.forEach(function(el) {
                    var label = el.getAttribute('aria-label');
                    var text = el.textContent || '';
                    var isSponsored = false;
                    
                    if (label && (label.toLowerCase() === 'sponsored' || label.toLowerCase() === 'bersponsor')) {
                        isSponsored = true;
                    } else if ((text === 'Sponsored' || text === 'Bersponsor') && el.children.length === 0) {
                        isSponsored = true;
                    }
                    if (isSponsored) { hancurkanContainerFB(el); }
                });

                var adLinks = document.querySelectorAll('a[href*="utm_medium=ppc"], a[href*="utm_source=meta"], a[href*="utm_id="]');
                adLinks.forEach(function(link) { hancurkanContainerFB(link); });
            } catch(e) {}
        }
        function hancurkanContainerFB(element) {
            var parent = element;
            for (var i = 0; i < 15; i++) {
                if (parent && parent.parentElement) {
                    parent = parent.parentElement;
                    if (parent.tagName === 'DIV' && (parent.getAttribute('data-pagelet') || parent.className.length > 5)) {
                        parent.style.setProperty('display', 'none', 'important');
                        parent.style.setProperty('height', '0px', 'important');
                    }
                }
            }
        }
        setInterval(sikatFacebook, 500);
    }

    // =======================================================================
    // 3. ZONA WEB UMUM & STREAMING (SILENT PURIFIER)
    // =======================================================================
    else {
        cssAman = `
            [src*="newrevive.detik.com"], [href*="newrevive.detik.com"], iframe[src*="newrevive"],
            [src*="yellowishgather.com"], [href*="yellowishgather.com"], iframe[src*="yellowishgather"],
            [class*="skin-ad"], [class*="ad-skin"], [class*="branding"], [class*="takeover"],
            .skin-layout, .bg-ads, .banner-ads, .ads-placement, body[class*="ad-"], 
            [id^="div-gpt-ad"], [id*="google_ads"], ins.adsbygoogle, [class*="adsbygoogle"],
            iframe[src*="googleads"], iframe[src*="doubleclick"], iframe[src*="adnxs"],
            iframe[name^="google_ads"], [data-google-query-id],
            .dfp-ad, .parallax-baca, .sisip_artikel, .box-komentar-ads, .detail__ads, 
            .ads-top, .ad-slot, .ad-wrapper, .sticky-ad, #baca-juga-ads, .mgbox,
            div[class*="iklan"], div[id*="iklan"], [id^="pro-display-"],
            .floating-ad, .bottom-ad, .popup-ad, [class*="interstitial"] {
                display: none !important; visibility: hidden !important; opacity: 0 !important;
                width: 0px !important; height: 0px !important; position: absolute !important;
                z-index: -99999 !important; pointer-events: none !important;
            }
            body, html { background-image: none !important; }
        `;
        
        function sikatPortalLokal() {
            try {
                // Taktik 1: Bypass Tombol Skip
                var genericSkipBtns = document.querySelectorAll('.videoAdUiSkipButton, .ima-ad-skip-button, .vjs-skip-button, [class*="skip-ad"], [id*="skip-ad"]');
                genericSkipBtns.forEach(btn => btn.click());
                
                // Taktik 2: Hancurkan Jebakan Teks LK21
                var allTextElements = document.querySelectorAll('div, button, span, a');
                allTextElements.forEach(function(el) {
                    var text = el.textContent.toLowerCase().trim();
                    if ((text.includes('skip ad') || text.includes('lewati iklan')) && el.children.length === 0) {
                        el.click(); 
                        if (el.parentElement) el.parentElement.click();
                    }
                    if (text.includes('klik di mana saja') || text.includes('this player contains ads')) {
                        var jebakan = el;
                        for (var i = 0; i < 5; i++) {
                            if (jebakan) {
                                jebakan.style.setProperty('display', 'none', 'important');
                                jebakan.style.setProperty('pointer-events', 'none', 'important');
                                jebakan = jebakan.parentElement;
                            }
                        }
                    }
                });

                // Taktik 3: Bypass Video Iklan
                var adVideos = document.querySelectorAll('.ima-ad-container video, .video-ad video, div[class*="ad"] video');
                adVideos.forEach(vid => {
                    if (!isNaN(vid.duration) && vid.currentTime < vid.duration) {
                        vid.muted = true; vid.currentTime = vid.duration || 9999;
                    }
                });
                var closeBtns = document.querySelectorAll('.btn-close-ads, .close-button, [class*="close-ad"], [id*="close-ad"]');
                closeBtns.forEach(btn => btn.click());
                
                // TAKTIK 4: SILENT PURIFIER (Melumpuhkan Link Jahat Tanpa Error)
                var shadyDomains = ['newrevive.detik.com', 'yellowishgather.com', 'tinyfish'];
                shadyDomains.forEach(function(domain) {
                    // Cari semua tag yang punya attribut src atau href ke domain nakal
                    var badElements = document.querySelectorAll(`[src*="${domain}"], [href*="${domain}"]`);
                    badElements.forEach(function(el) {
                        if (el.tagName === 'A') {
                            el.removeAttribute('href'); // Cabut link-nya
                            el.href = '#'; // Ganti jadi kosong
                            el.target = '_self'; // Jangan boleh buka tab baru
                        } else if (el.tagName === 'SCRIPT' || el.tagName === 'IFRAME') {
                            el.remove(); // Hapus script/iframe-nya
                        } else if (el.parentElement) {
                            el.parentElement.style.display = 'none';
                        }
                    });
                });
            } catch(e) {}
        }
        setInterval(sikatPortalLokal, 300); 
    }

    if (cssAman !== '') {
        const styleTag = document.createElement('style');
        styleTag.type = 'text/css';
        styleTag.appendChild(document.createTextNode(cssAman));
        const injectStyle = () => {
            if (!document.head.contains(styleTag)) document.head.appendChild(styleTag);
        };
        injectStyle();
    }
})();
