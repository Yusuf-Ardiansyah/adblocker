﻿(function() {
    'use strict';
    function sikatIklan() {
        try {
            var skipBtn = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button');
            if (skipBtn) skipBtn.click();
            var adVideo = document.querySelector('.ad-showing video');
            if (adVideo && !isNaN(adVideo.duration)) adVideo.currentTime = adVideo.duration;
            var adBanners = document.querySelectorAll('ytm-promoted-sparkles-web-renderer, ytm-companion-ad-renderer, .ad-container, ad-slot-renderer, #masthead-ad, ytd-ad-slot-renderer, ytd-promoted-sparkles-web-renderer, .ytd-in-feed-ad-layout-renderer');
            adBanners.forEach(function(el) { el.style.display = 'none'; });
            var confirmBtn = document.querySelector('yt-confirm-dialog-renderer .yt-spec-button-shape-next');
            if (confirmBtn) confirmBtn.click();
        } catch(e) {}
    }
    const observer = new MutationObserver(() => { sikatIklan(); });
    observer.observe(document.body, { childList: true, subtree: true });
    setInterval(sikatIklan, 1000);
    console.log("👑 Ekstensi Sultan AdBlocker VIP Berhasil Dimuat!");
})();
